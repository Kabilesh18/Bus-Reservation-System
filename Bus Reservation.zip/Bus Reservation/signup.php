<?php
        if(isset($_POST['signup'])){
            $servername="127.0.0.1:3307";
            $username="root";
            $password="root";
            $db="busreservation";
            $con=mysqli_connect($servername,$username,$password,$db);
            if(!$con){
                die("Connection failed".mysqli_connect_error);
            }
            $uname=$_POST['uname'];
            $pass=$_POST['pass'];
            $email=$_POST['email'];
            $mobno=$_POST['mobno'];
            $age=$_POST['age'];
            $gender=$_POST['gender'];
            $query="insert into login values('$uname','$pass','$email','$mobno','$age','$gender')";
            $run=mysqli_query($con,$query);
            if($run){ 
                header("Location:index.html");
                exit();
            }
            else{
                echo "<h1>Unable to SignUp.</h1>";
            }
        }
?>