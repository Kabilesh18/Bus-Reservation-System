<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        table{
            border-collapse: collapse;
        }
        th,td {
            border: 1px solid black;
            padding: 8px;
        }
        .container {
            background-color:aqua;
            background-repeat: no-repeat;
            background-size: cover;
            border-style: groove;
            margin-top: 200px;
            margin-bottom: 100px;
            margin-right: 520px;
            margin-left: 100px;
            opacity: 1;
            padding: 23px;
            background-color: aqua;
            padding-top: 50px;
            padding-bottom: 50px;
            border-radius: 10px;
            opacity: 0.8;
        }
    </style>
</head>
<body>
    
</body>
</html>
<?php
    if(isset($_POST['submit'])){
        $servername="127.0.0.1:3307";
        $username="root";
        $password="root";
        $db="busreservation";
        $con=mysqli_connect($servername,$username,$password,$db);
        if(!$con){
            die("connection failed".mysqli_connect_error());
        }
        $source=$_POST['from'];
        $destination=$_POST['destination'];
        $query="select * from availbuses where source='$source' and destination='$destination'";
        $run=mysqli_query($con,$query);
        if(mysqli_num_rows($run)>0){
            echo '<div class="container">';
            echo '<form>';
            echo '<table>';
            echo '<tr>';
            echo '<td>Bus ID</td>';
            echo '<td>Bus Name</td>';
            echo '<td>Ticket Price</td>';
            echo '</tr>';
            while($row=mysqli_fetch_assoc($run)){
                echo '<tr>';
                echo '<td>'.$row["busid"].'</td>';
                echo '<td>'.$row["busname"].'</td>';
                echo '<td>'.$row["price"].'</td>';
                echo '</tr>';
            }
            echo '</table>';
            echo '</form>';
            echo "<br><br>";
            echo "Enter the details below to book the seats...";
            echo "<form action='reserve.php' method='post'>";
            echo '<table>';
            echo '<tr>';
            echo '<td>BUSID</td>';
            echo '<td>USER NAME</td>';
            echo '<td>BUS NAME</td>';
            echo '<td>SEATS</td>';
            echo '<td>BOOK</td>';
            echo '</tr>';
            echo '<tr>';
            echo '<td><input type="number" name="busid" id="busid" placeholder="Bus ID" required></td>';
            echo '<td><input type="text" name="uname" id="uname" placeholder="User Name" required></td>';
            echo '<td><input type="text" name="busname" id="busname" placeholder="Bus Name required"></td>';
            echo '<td><input type="number" name="seat" id="seat" placeholder="Seat" required></td>';
            echo '<td><input type="submit" value="BOOK" name="book" id="book" placeholder="Book"></td>';
            echo '</tr>';
            echo '</table>';
            echo '</form>';
            echo '</div>';
        }
        else{
            echo "NO BUSES AVAILABLE FOR THIS ROUTE";
            echo "<a href='booking.html'>click here</a>";
        }
    }
?>