<?php
    if(isset($_POST['login'])){
        $servername="127.0.0.1:3307";
        $username="root";
        $password="root";
        $db="busreservation";
        $con=mysqli_connect($servername,$username,$password,$db);
        if(!$con){
            die("connection failed".mysqli_connect_error());
        }
        $uname=$_POST['uname'];
        $pass=$_POST['pass'];
        $query="select * from login where uname='$uname' and pass='$pass'";
        $run=mysqli_query($con,$query);
        if($run){
            if(mysqli_num_rows($run)>0){
                header("Location:booking.html");
                exit();
            }
            else{
                echo "User not found !";
                echo "<a href='index.html'>click Here to move login</a>";
            }
        }
    }
?>