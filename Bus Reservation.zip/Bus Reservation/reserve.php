<?php
        if(isset($_POST['book'])){
            $servername="127.0.0.1:3307";
            $username="root";
            $password="root";
            $db="busreservation";
            $con=mysqli_connect($servername,$username,$password,$db);
            if(!$con){
                die("connection failed".mysqli_connect_error());
            }
            $busid=$_POST['busid'];
            $uname=$_POST['uname'];
            $busname=$_POST['busname'];
            $seat=$_POST['seat'];
            $query="insert into booked values('$busid','$uname','$busname','$seat')";
            $execute=mysqli_query($con,$query);
            if($execute){
                echo "<img src='book.jpg' alt='Booked'>";
                echo "<a href='booking.html'>click here to book more</a>";
            }
            else{
                echo "no ticket booked";
            }
        }
?>